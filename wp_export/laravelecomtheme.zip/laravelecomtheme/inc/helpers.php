<?php
// Placeholder for theme helpers. Menu align rendering can be added here to split left/right.
