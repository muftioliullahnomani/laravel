<?php
/* Template Name: Checkout */
get_header();
?>
<main class="container" style="max-width:800px;margin:20px auto;padding:0 16px">
  <h1>Checkout (COD)</h1>
  <?php echo do_shortcode('[ecom_checkout]'); ?>
</main>
<?php get_footer(); ?>
