<?php
/* Template Name: Cart */
get_header();
?>
<main class="container" style="max-width:1000px;margin:20px auto;padding:0 16px">
  <h1>Cart</h1>
  <?php echo do_shortcode('[ecom_cart]'); ?>
</main>
<?php get_footer(); ?>
