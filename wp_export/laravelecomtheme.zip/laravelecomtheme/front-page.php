<?php get_header(); ?>
<main class="container">
  <h1>Home</h1>
  <?php echo do_shortcode('[ecom_products limit="24"]'); ?>
</main>
<?php get_footer(); ?>
