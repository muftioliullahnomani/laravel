<?php
// Load core pieces
require_once __DIR__ . '/cpt/Product.php';
require_once __DIR__ . '/cpt/Order.php';
require_once __DIR__ . '/cpt/OrderItem.php';
require_once __DIR__ . '/cpt/HomepageSection.php';
require_once __DIR__ . '/tax/ProductCat.php';
require_once __DIR__ . '/Options.php';
require_once __DIR__ . '/Menus.php';
require_once __DIR__ . '/Cart.php';
require_once __DIR__ . '/Checkout.php';
require_once __DIR__ . '/Admin/Orders.php';
require_once __DIR__ . '/REST/Import.php';
require_once __DIR__ . '/Shortcodes/Products.php';
